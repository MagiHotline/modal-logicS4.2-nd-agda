{-# OPTIONS --cubical-compatible --safe #-}

module System.Modal where

open import Data.Nat as Nat using (ℕ; zero; suc; _+_; _<_; _≤_)
open import Data.List as List using (List; []; _∷_; map)
open import Data.Product using (_×_; _,_)
open import Data.String using (String)
open import Relation.Binary.PropositionalEquality as Eq using (_≡_; refl)
open import Data.Fin using (Fin; zero; suc; fromℕ; toℕ)
open import Data.Fin.Subset as Subset 

-- We first define modal formulas 
data mf : Set where 
    atom : String → mf
    BOT : mf
    TOP : mf
    _⇒_ : mf → mf → mf
    ¬_ : mf → mf
    _∧_ : mf → mf → mf
    _∨_ : mf → mf → mf
    □_ : mf → mf
    ◇_ : mf → mf

infixr 10 _⇒_  
infixr 15 _∨_  
infixr 20 _∧_  
infix  30 □_  
infix  30 ◇_   
infix  30 ¬_

-- Next, we define position formulas where a Position formula is an expression A^s 
-- where A is a modal formula and s is a position.
-- A position is a finite set of tokens where the empty set denotes the empty position 
-- and s,t denotes the union of positions s ∪ t and s,x denotes the position s ∪ {x}

-- A token is defined in the proof assistant as a term of Fin n. 
-- In STD Agda, Fin n is the type of natural numbers less than n.
-- where n determines the size of the set. 
-- A position si defined as Subset n. The type Subset n represents a subset of Fin n 

position : {n : ℕ} → Set
position {n} = Subset n 

-- DA CAMBIARE
-- RICERCA COME SONO IMPLEMENTATI GLI INSIEMI IN AGDA
-- Alternativa: usare liste per le positions (duplication and contraction)
-- Posizione come funzione () insieme come funzioni nei Proof 

-- POSITIONS COME LISTE ? 
-- problema dell'ordine (List != Set) {x, y} != {y, x}
-- problema delle duplicazioni {x, x, y} != {x, y}
-- A : Set 
-- position : List A 

infix 6 _^_ 
record pf {n : ℕ} : Set where 
   constructor _^_ 
   field 
    A : mf
    s : position {n}

fresh : {n : ℕ} → Fin n → List (pf) → Set
fresh x Γ = x ∉ (⋃ (map (pf.s) Γ))


